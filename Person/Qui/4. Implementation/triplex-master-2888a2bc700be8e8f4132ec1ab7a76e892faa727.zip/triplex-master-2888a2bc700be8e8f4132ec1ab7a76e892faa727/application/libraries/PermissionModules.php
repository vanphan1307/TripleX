<?php if ( ! defined( 'BASEPATH' ) ) {
	exit( 'No direct script access allowed' );
}
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/8/2017
 * Time: 4:36 PM
 */
class PermissionModules {

	public function has_permission_test_score_module(){

	}

	public function has_permission_course_lists(){

	}

	public function has_permission_list(){

	}

}