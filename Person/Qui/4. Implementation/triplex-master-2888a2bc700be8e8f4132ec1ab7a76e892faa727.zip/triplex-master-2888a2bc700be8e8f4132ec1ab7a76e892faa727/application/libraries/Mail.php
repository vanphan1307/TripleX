<?php

use PHPMailer\PHPMailer\PHPMailer;

/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/20/2017
 * Time: 8:36 PM
 */

class Mail {

	protected $phpMailer;
	public function __construct() {
		$this->phpMailer = new PHPMailer(true);
		$this->set_core();
	}

	private function set_core(){
		$this->phpMailer->SMTPDebug = 2;                                 // Enable verbose debug output
		$this->phpMailer->isSMTP();                                      // Set mailer to use SMTP
		$this->phpMailer->Host = 'ssl://smtp.gmail.com';  // Specify main and backup SMTP servers
		$this->phpMailer->SMTPAuth = true;                               // Enable SMTP authentication
		$this->phpMailer->Username = 'triplexcapstone@gmail.com';                 // SMTP username
		$this->phpMailer->Password = 'TriplexAdmin123';                           // SMTP password
		$this->phpMailer->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
		$this->phpMailer->Port = 465;
	}

	public function send_mail($subject, $body, $setFrom, $recipient, $AltBody = null){
		//Recipients
		$this->phpMailer->setFrom($setFrom, 'Mailer');
		$this->phpMailer->addAddress($recipient, 'Joe User');     // Add a recipient
		$this->phpMailer->addReplyTo($setFrom, 'Information');
		$this->phpMailer->isHTML(true);                                  // Set email format to HTML
		$this->phpMailer->Subject = $subject;
		$this->phpMailer->Body    = $body;
		$this->phpMailer->AltBody = $AltBody;
		$this->phpMailer->send();
		// TCP port to connect to
	}
}