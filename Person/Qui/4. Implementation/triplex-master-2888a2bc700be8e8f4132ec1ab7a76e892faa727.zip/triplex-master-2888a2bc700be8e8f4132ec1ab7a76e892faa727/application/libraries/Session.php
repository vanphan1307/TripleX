<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/6/2017
 * Time: 8:24 PM
 */

class Session {

	public function __construct() {
		if(!isset($_SESSION)) {
			session_start();
		}
	}

	public static function set($key, $value){
		$_SESSION[$key] = $value;
	}

	public static function get($key){
		if(!isset($_SESSION[$key])){
			return null;
		}
		return $_SESSION[$key];
	}

	public static function update($key, $value){
		$_SESSION[$key] = $value;
	}

	public static function destroy($key){
		session_destroy();
	}

	public static function get_current_user(){
		$key = Cookie::get('sessionKey');
		if(empty($key) || $key == 1){
			return null;
		}
		if(empty(self::get($key))){
			return null;
		}
		return self::get($key);
	}

}