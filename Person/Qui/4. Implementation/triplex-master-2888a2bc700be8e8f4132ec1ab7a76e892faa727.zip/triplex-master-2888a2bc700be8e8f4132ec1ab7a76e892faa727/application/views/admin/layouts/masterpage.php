<!DOCTYPE html>
<html lang="en-us">
<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <!-- #CSS Links -->
    <!-- Basic Styles -->
    <link rel="stylesheet" type="text/css" media="screen" href="<?= base_url();?>assets/smartadmin/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" media="screen" href="<?= base_url();?>assets/fontAwesome/css/font-awesome.min.css">

    <!-- SmartAdmin Styles : Caution! DO NOT change the order -->
    <link rel="stylesheet" type="text/css" media="screen" href="<?= base_url();?>assets/smartadmin/css/smartadmin-production-plugins.min.css">
    <link rel="stylesheet" type="text/css" media="screen" href="<?= base_url();?>assets/smartadmin/css/smartadmin-production.min.css">
    <link rel="stylesheet" type="text/css" media="screen" href="<?= base_url();?>assets/smartadmin/css/smartadmin-skins.min.css">

    <!-- Demo purpose only: goes with demo.js, you can delete this css when designing your own WebApp -->
    <link rel="stylesheet" type="text/css" media="screen" href="<?= base_url();?>assets/smartadmin/css/demo.min.css">

    <!-- #GOOGLE FONT -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,300,400,700">


    <!--================================================== -->

    <!-- PACE LOADER - turn this on if you want ajax loading to show (caution: uses lots of memory on iDevices)-->
    <script data-pace-options='{ "restartOnRequestAfter": true }' src="<?= base_url();?>/assets/smartadmin/js/plugin/pace/pace.min.js"></script>

    <script src="<?= base_url();?>assets/smartadmin/js/libs/jquery-2.1.1.min.js"></script>

    <script src="<?= base_url();?>assets/smartadmin/js/libs/jquery-ui-1.10.3.min.js"></script>

    <!-- IMPORTANT: APP CONFIG -->
    <script src="<?= base_url();?>assets/smartadmin/js/app.config.js"></script>

    <!-- JS TOUCH : include this plugin for mobile drag / drop touch events-->
    <script src="<?= base_url();?>assets/smartadmin/js/plugin/jquery-touch/jquery.ui.touch-punch.min.js"></script>

    <!-- BOOTSTRAP JS -->
    <script src="<?= base_url();?>assets/smartadmin/js/bootstrap/bootstrap.min.js"></script>

    <!-- CUSTOM NOTIFICATION -->
    <script src="<?= base_url();?>assets/smartadmin/js/notification/SmartNotification.min.js"></script>

    <!-- JARVIS WIDGETS -->
    <script src="<?= base_url();?>assets/smartadmin/js/smartwidgets/jarvis.widget.min.js"></script>

    <!-- EASY PIE CHARTS -->
    <script src="<?= base_url();?>assets/smartadmin/js/plugin/easy-pie-chart/jquery.easy-pie-chart.min.js"></script>

    <!-- SPARKLINES -->
    <script src="<?= base_url();?>assets/smartadmin/js/plugin/sparkline/jquery.sparkline.min.js"></script>

    <!-- JQUERY VALIDATE -->
    <script src="<?= base_url();?>assets/smartadmin/js/plugin/jquery-validate/jquery.validate.min.js"></script>

    <!-- JQUERY MASKED INPUT -->
    <script src="<?= base_url();?>assets/smartadmin/js/plugin/masked-input/jquery.maskedinput.min.js"></script>

    <!-- JQUERY SELECT2 INPUT -->
    <script src="<?= base_url();?>assets/smartadmin/js/plugin/select2/select2.min.js"></script>

    <!-- JQUERY UI + Bootstrap Slider -->
    <script src="<?= base_url();?>assets/smartadmin/js/plugin/bootstrap-slider/bootstrap-slider.min.js"></script>

    <!-- browser msie issue fix -->
    <script src="<?= base_url();?>assets/smartadmin/js/plugin/msie-fix/jquery.mb.browser.min.js"></script>

    <!-- FastClick: For mobile devices -->
    <script src="<?= base_url();?>assets/smartadmin/js/plugin/fastclick/fastclick.min.js"></script>

    <!--[if IE 8]>

    <h1>Your browser is out of date, please update your browser by going to www.microsoft.com/download</h1>

    <![endif]-->

    <!-- Demo purpose only -->
    <script src="<?= base_url();?>assets/smartadmin/js/demo.js"></script>

    <!-- MAIN APP JS FILE -->
    <script src="<?= base_url();?>assets/smartadmin/js/app.js"></script>

    <!-- ENHANCEMENT PLUGINS : NOT A REQUIREMENT -->
    <!-- Voice command : plugin -->
    <script src="<?= base_url();?>assets/smartadmin/js/speech/voicecommand.min.js"></script>

    <!-- SmartChat UI : plugin -->
    <script src="<?= base_url();?>assets/smartadmin/js/smart-chat-ui/smart.chat.ui.min.js"></script>

    <script src="<?= base_url();?>assets/smartadmin/js/smart-chat-ui/smart.chat.manager.min.js"></script>

</head>
<body>
    <!-- #HEADER -->
    <div id="header"><?= $header ?></div>
    <!-- #NAVIGATION -->
    <!-- Left panel : Navigation area -->
    <aside id="left-panel"><?= $nav ?></aside>
    <!-- MAIN PANEL -->
    <div id="main" role="main">
        <!-- RIBBON -->
        <div id="ribbon">
        </div>
        <!-- END RIBBON -->
        <!-- MAIN CONTENT -->
        <div id="content">
            <?php ?>
	        <?= $contents ?>
        </div>
        <!-- END MAIN CONTENT -->
    </div>
    <!-- PAGE FOOTER -->
    <div class="page-footer"><?= $footer ?></div>

    <script type="text/javascript">
        // DO NOT REMOVE : GLOBAL FUNCTIONS!
        $(document).ready(function() {
            pageSetUp();
        })
    </script>

</body>
</html>