<div class="rows">
	<!-- widget grid -->
	<section id="widget-grid" class="">
		<!-- START ROW -->
		<div class="row">
			<!-- NEW COL START -->
			<article class="col-sm-12 col-md-12 col-lg-12">

				<!-- Widget ID (each widget will need unique ID)-->
				<div class="jarviswidget" id="wid-id-1" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-custombutton="false">
					<!-- widget options:
					usage: <div class="jarviswidget" id="wid-id-0" data-widget-editbutton="false">

					data-widget-colorbutton="false"
					data-widget-editbutton="false"
					data-widget-togglebutton="false"
					data-widget-deletebutton="false"
					data-widget-fullscreenbutton="false"
					data-widget-custombutton="false"
					data-widget-collapsed="true"
					data-widget-sortable="false"

					-->
					<header>
						<span class="widget-icon"> <i class="fa fa-edit"></i> </span>
						<h2>Review data </h2>

					</header>

					<!-- widget div-->
					<div>

						<!-- widget edit box -->
						<div class="jarviswidget-editbox">
							<!-- This area used as dropdown edit box -->

						</div>
						<!-- end widget edit box -->

						<!-- widget content -->
						<div class="widget-body">
                            <div class="padding-5">
                                <a href="<?= base_url()?>admin/users" class="btn btn-small btn-default">Back</a>
                                <a href="<?= base_url()?>admin/users?import=<?= $filePath ?>"class="btn btn-small btn-primary" style="float: right;">Accept</a>
                            </div>
							<div class="table-responsive">
								<table class="table table-bordered">
									<thead>
									<tr>
										<th>MSSV</th>
										<th>Full name</th>
										<th>SDT</th>
										<th>Email</th>
										<th>Class</th>
										<th>academic year</th>
										<th></th>
									</tr>
									</thead>
									<tbody>
									<?php
									foreach ($users as $user){
										?>
										<tr>
											<td><?= $user['mssv'] ?></td>
											<td><?= $user['first_name'] . ' ' . $user['surname'] ?></td>
											<td><?= $user['mobilephone'] ?></td>
											<td><?= $user['mobilephone'] ?></td>
											<td></td>
											<td></td>
											<td></td>
										</tr>
										<?php
									}
									?>
									</tbody>
								</table>
								<div class="row">

								</div>
							</div>
						</div>
						<!-- end widget content -->

					</div>
					<!-- end widget div -->

				</div>
				<!-- end widget -->

			</article>
			<!-- END COL -->
		</div>
		<!-- END ROW -->
	</section>
	<!-- end widget grid -->
</div>
