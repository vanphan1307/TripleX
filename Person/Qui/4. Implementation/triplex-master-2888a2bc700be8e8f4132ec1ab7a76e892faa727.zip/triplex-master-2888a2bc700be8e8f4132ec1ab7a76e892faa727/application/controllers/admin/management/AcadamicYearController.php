<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/6/2017
 * Time: 8:56 PM
 */

class AcadamicYearController extends Admin_Controller {

	protected $view_admin_academic_year = 'admin/acadamicyears/index';

	/**
	 * users constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	public function index(){
		$acadamic_years = $this->AcademicYears_model->get_all();
		$data = [];
		$data['acadamic_years'] = $acadamic_years;
		$this->load_view($this->view_admin_academic_year, $data);
	}

	public function create(){
		if($this->input->post()){
			$name = $this->input->post('name');
			$start_time = $this->input->post('startdate');
			$end_time = $this->input->post('finishdate');
			$data = [];
			$data['name'] = $name;
			$data['start_date'] = explode('.', $start_time)[2]. '-'.explode('.', $start_time)[0].'-'.explode('.', $start_time)[1]. ' 00:00:00';
			$data['end_date'] = explode('.', $end_time)[2]. '-'.explode('.', $end_time)[0].'-'.explode('.', $end_time)[1]. ' 00:00:00';
			$this->AcademicYears_model->insert($data);
			redirect(base_url().'admin/acadamicyears');
		}else{
			redirect(base_url().'admin/acadamicyears');
		}
	}

}