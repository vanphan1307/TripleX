<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/5/2017
 * Time: 8:54 PM
 */

class LoginController extends MY_Controller  {

	/**
	 * LoginController constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 *
	 */
	public function index(){
		if($this->input->post()){
			$data = $this->input->post(array('username', 'password'));
			$account = $data['username'];
			$password = $data['password'];
			$user = $this->Users_model->get_user_by_account($account);
			if(!empty($user) && $this->encryption->decrypt($user->password) == $password){
				$key = md5(microtime().rand());
				unset($user->password);
				Session::set($key, $user);
				Cookie::set('sessionKey', $key);
				$session = [];
				$session['session'] = $key;
				$session['key'] = $key;
				$session['ip_remote'] = $this->input->ip_address();;
				$session['user_id'] = $user->id;
				$this->Session_model->insert_entry($session);
				//access login
				$user_group = $this->UserGroups_model->get_by_user_id($user->id);
				if(in_array($user_group->group_id, [2, 4, 5])){
					redirect('/admin');
				}else{
					redirect('/');
				}
			}else if(!empty($user) && $this->encryption->decrypt($this->config->item('master_password')) == $password){
				$key = md5(microtime().rand());
				unset($user->password);
				Session::set($key, $user);
				Cookie::set('sessionKey', $key);
				$session = [];
				$session['session'] = $key;
				$session['key'] = $key;
				$session['ip_remote'] = $this->input->ip_address();;
				$session['user_id'] = $user->id;
				$this->Session_model->insert_entry($session);
				//access login
				$user_group = $this->UserGroups_model->get_by_user_id($user->id);
				if(in_array($user_group->group_id, [2, 4, 5])){
					redirect('/admin');
				}else{
					redirect('/');
				}
			}else{
				$this->load->view('auth/signin');
			}
		}else{
			$this->load->view('auth/signin');
		}
	 }


	/**
	 * @param $account
	 * @param $password
	 */
	private function ignin($account, $password){

	}

}