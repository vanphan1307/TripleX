<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/9/2017
 * Time: 10:50 PM
 */

class AcademicYears_model extends CI_Model {

	public $table_name = 'academic_years';

	public function __construct() {
		parent::__construct();
	}

	public function get_all(){
		$sql   = "SELECT `id`, `name`,`start_date`, `end_date` FROM `academic_years` WHERE `deleted_date` IS NULL OR `deleted_date` = ''";
		$query = $this->db->query( $sql );
		return $query->result();
	}

	public function insert($data){
		$this->db->insert( $this->table_name, $data );
		$insert_id = $this->db->insert_id();
		return $insert_id;
	}

}