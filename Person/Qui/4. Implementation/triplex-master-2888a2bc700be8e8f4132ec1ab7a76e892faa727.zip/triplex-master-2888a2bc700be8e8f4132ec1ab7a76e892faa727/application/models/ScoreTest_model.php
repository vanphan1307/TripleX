<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/9/2017
 * Time: 10:50 PM
 */

class ScoreTest_model extends CI_Model {

	public $table_name = 'score_test';

	public function __construct() {
		parent::__construct();
	}

	public function get_all(){
		$sql   = "SELECT st.`id`, st.`courses_id`, st.`user_id`, st.`attendance`, st.`mid_term`, st.`first_time`, st.`second_time`, st.`DTB`, st.`percent_attendance`, st.`percent_mid_term`, st.`percent_last_test`, u.`mssv` , u.`first_name`, u.`surname`, c.`code` as course_code FROM `score_test` as st, `users` as u, `courses` as c WHERE u.`id` = st.`user_id` AND st.`courses_id` = c.`id` AND st.`deleted_date` IS NULL OR st.`deleted_date` = ''";
		$query = $this->db->query( $sql );
		return $query->result();
	}


	public function get_by_course_id_and_user_id($courses_id , $user_id){
		$sql   = "SELECT st.`courses_id`, st.`user_id`, st.`attendance`, st.`mid_term`, st.`first_time`, st.`second_time`, st.`DTB`, st.`percent_attendance`, st.`percent_mid_term`, st.`percent_last_test` FROM `score_test` as st WHERE st.`courses_id` = ? AND st.`user_id` = ?  AND st.`deleted_date` IS NULL OR st.`deleted_date` = ''" ;
		$query = $this->db->query( $sql, array($courses_id, $user_id));
		if(!empty($query->result())){
			return $query->result()[0];
		}else{
			return null;
		}
	}

	public function insert($data){
		$this->db->insert( $this->table_name, $data );
		$insert_id = $this->db->insert_id();
		return $insert_id;
	}

}