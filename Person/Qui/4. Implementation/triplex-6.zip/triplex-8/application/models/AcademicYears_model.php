<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/9/2017
 * Time: 10:50 PM
 */

class AcademicYears_model extends CI_Model {

	public $table_name = 'academic_years';

	public function __construct() {
		parent::__construct();
	}

}