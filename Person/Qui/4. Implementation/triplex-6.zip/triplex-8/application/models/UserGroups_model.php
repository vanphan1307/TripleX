<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/5/2017
 * Time: 11:53 PM
 */

class UserGroups_model extends CI_Model {

	public $table_name = 'users_groups';

	public function __construct() {
		parent::__construct();
	}

	public function get_by_user_id($user_id){
		$sql   = "SELECT * FROM `users_groups` WHERE `user_id` = ?;" ;
		$query = $this->db->query( $sql, array($user_id) );
		if(!empty($query->result())){
			return $query->result()[0];
		}else{
			return null;
		}
	}
}