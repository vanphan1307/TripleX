<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/5/2017
 * Time: 11:52 PM
 */

class Users_model extends CI_Model {

	protected $table_name = 'users';

	public function __construct() {
		parent::__construct();
	}

	/**
	 * @return mixed
	 */
	public function get_all(){
		$sql   = "SELECT `id`, `full_name`,`first_name`, `surname`, `email`, `account`, `gender`, `mobilephone`, `img`, `mssv` FROM `users`;" ;
		$query = $this->db->query( $sql );
		return $query->result();
	}

	public function get_by_password_restore($password_restore){
		$sql   = "SELECT `id`, `full_name`, `email`, `password` FROM users WHERE `password_restore` LIKE ?;" ;
		$query = $this->db->query( $sql, array($password_restore) );
		if(!empty($query->result())){
			return $query->result()[0];
		}else{
			return null;
		}
	}

	/**
	 * @param null $email
	 *
	 * @return null
	 */
	public function get_user_by_email($email = null){
		$sql   = "SELECT `id`, `full_name`, `email`, `password` FROM users WHERE `email` LIKE ?;" ;
		$query = $this->db->query( $sql, array($email) );
		if(!empty($query->result())){
			return $query->result()[0];
		}else{
			return null;
		}
	}

	/**
	 * @param null $account
	 *
	 * @return null
	 */
	public function get_user_by_account($account = null){
		$sql   = "SELECT `id`, `full_name`, `email`, `password` FROM users WHERE `account` LIKE ?;" ;
		$query = $this->db->query( $sql, array($account) );
		if(!empty($query->result())){
			return $query->result()[0];
		}else{
			return null;
		}
	}

	/**
	 * @return mixed
	 */
	public function get_last_ten_entries() {
		$sql   = "SELECT * FROM ?";
		$query = $this->db->query( $sql, array( $this->table_name ) );

		return $query->result();
	}



	/**
	 * @param null $user
	 *
	 * @return bool
	 */
	public function insert_entry( $user = null ) {
		if ( empty( $user ) ) {
			return false;
		}
		$data              = [];
		$data['full_name'] = $user['full_name'];
		$data['password']  = $user['password'];
		$data['email']     = $user['email'];
		$this->db->insert( $this->table_name, $data );

		return true;
	}


	/**
	 * @param $id
	 * @param $token
	 */
	public function update_token_reset_password($id, $token){
		$data = array(
			'password_restore' => $token,
		);
		$this->db->where('id', $id);
		$this->db->update($this->table_name, $data);
	}
	/**
	 * @param $id
	 * @param $password
	 */
	public function update_password($id, $password){
		$data = array(
			'password' => $password,
			'password_restore' => null,
		);
		$this->db->where('id', $id);
		$this->db->update($this->table_name, $data);
	}

	public function update_entry() {

	}

	/**
	 * @param $data
	 */
	public function insert_multi($data){
		$this->db->insert_batch( $this->table_name, $data );
	}
}