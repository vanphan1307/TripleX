<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/16/2017
 * Time: 10:54 PM
 */

class TestSchedule_model extends CI_Model {

	public $table_name = 'test_schedule';

	public function __construct() {
		parent::__construct();
	}

	/**
	 * @param null $schedule
	 *
	 * @return bool
	 */
	public function insert_entry( $schedule = null ) {
		if ( empty( $schedule ) ) {
			return false;
		}
		$data              = [];
		$data['name'] = $schedule['name'];
		$data['img']  = $schedule['img'];
		$data['created_at']  = date('Y-m-d H:i:s');
		$data['created_by']  = !empty(Session::get_current_user()) ? Session::get_current_user()->id : -1;
		$this->db->insert( $this->table_name, $data );
		return true;
	}

	/**
	 * @param $id
	 */
	public function delete($id){
		$data              = [];
		$data['deleted_at']  = date('Y-m-d H:i:s');
		$data['deleted_by']  = !empty(Session::get_current_user()) ? Session::get_current_user()->id : -1;
		$this->db->where('id', $id);
		$this->db->update($this->table_name, $data);
	}

	/**
	 * @return mixed
	 */
	public function fetch_all(){
		$sql   = "SELECT `id`, `name`, `img`, `created_at` FROM `test_schedule` WHERE `deleted_at` IS NULL OR `deleted_at` = '';" ;
		$query = $this->db->query( $sql );
		return $query->result();
	}
}