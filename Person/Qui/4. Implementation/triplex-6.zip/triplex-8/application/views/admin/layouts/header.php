<div id="logo-group">
    <!-- PLACE YOUR LOGO HERE -->
<!--    <span id="logo"> <img src="assets/smartadmin/img/logo.png" alt="SmartAdmin"> </span>-->
    <span id="logo" style="min-width: 180px"><span style="color: #ff6600; transition: .5s; -moz-transition: .5s; -webkit-transition: .5s; -o-transition: .5s; font-family: 'Muli', sans-serif; font-size: x-large;"> TRIPLEX LOGO</span></span>
    <!-- END LOGO PLACEHOLDER -->
</div>


<!-- #TOGGLE LAYOUT BUTTONS -->
<!-- pulled right: nav area -->
<div class="pull-right">

    <!-- collapse menu button -->
    <div id="hide-menu" class="btn-header pull-right">
        <span> <a href="javascript:void(0);" data-action="toggleMenu" title="Collapse Menu"><i class="fa fa-reorder"></i></a> </span>
    </div>
    <!-- end collapse menu -->

    <!-- logout button -->
    <div id="logout" class="btn-header transparent pull-right">
        <span> <a href="<?= base_url();?>signout" title="Sign Out" data-logout-msg="You can improve your security further after logging out by closing this opened browser"><i class="fa fa-sign-out"></i></a> </span>
    </div>
    <!-- end logout button -->
</div>
<!-- end pulled right: nav area -->