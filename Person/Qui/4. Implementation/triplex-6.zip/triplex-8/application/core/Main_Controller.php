<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/5/2017
 * Time: 10:41 PM
 */

class Main_Controller extends MY_Controller {
	public $user = null;
	/**
	 * Main_Controller constructor.
	 */
	public function __construct() {
		parent::__construct();
		$this->isLogon();
	}

	public function isLogon(){
		$key = Cookie::get('sessionKey');
		if(empty($key) || $key == 1){
			redirect('/signin');
			exit;
		}
		if(empty(Session::get($key))){
			Cookie::destroy('sessionKey');
			redirect('/signin');
			exit;
		}
		$this->user = Session::get($key);
		$userId = $this->user->id;
		$user_group = $this->UserGroups_model->get_by_user_id($userId);
	}
}