<?php if ( ! defined( 'BASEPATH' ) ) {
	exit( 'No direct script access allowed' );
}

class Template {

	public function __construct() {}

	/**
	 * array data template
	*/
	var $template_data = array();

	/**
	 * array style sheet
	*/
	var $css = array();

	/**
	 * array javascript
	*/
	var $js = array();

	public function set( $name, $value ) {
		$this->template_data[ $name ] = $value;
	}

	public function set_css($styles = array()){
		foreach ($styles as $style){
			array_push($this->css, $style);
		};

	}

	public function set_js($scripts = array()){
		foreach ($scripts as $script){
			array_push($this->js, $script);
		};
	}

	public function load( $template = '', $view = [], $view_data = array(), $return = false ) {
		if(sizeof($view) == 0){
			throw new Exception("Page is not defined!");
		}
		$this->CI =& get_instance();
		// load header
		$this->set( 'header', $this->CI->load->view( $view['header'], $view_data, true ) );
		// nav
		if(!empty($view['nav'])){
			$this->set( 'nav', $this->CI->load->view( $view['nav'], $view_data, true ) );
		}
		//load contents
		$this->set( 'contents', $this->CI->load->view( $view['page'], $view_data, true ) );
		//load footer
		$this->set( 'footer', $this->CI->load->view( $view['footer'], $view_data, true ) );
		return $this->CI->load->view( $template, $this->template_data, $return );
	}
}