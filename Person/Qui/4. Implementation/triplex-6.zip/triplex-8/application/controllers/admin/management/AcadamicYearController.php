<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/6/2017
 * Time: 8:56 PM
 */

class AcademicYearController extends Admin_Controller {

	protected $view_admin_academic_year = 'admin/acadamicyears/index';

	/**
	 * users constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	public function index(){
		$this->load_view($this->view_admin_academic_year);
	}

	public function create(){

	}

}