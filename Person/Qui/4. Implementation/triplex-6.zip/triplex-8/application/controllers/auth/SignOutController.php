<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/5/2017
 * Time: 8:54 PM
 */

class SignOutController extends MY_Controller  {

	/**
	 * LoginController constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 *
	 */
	public function index(){
		$key = Cookie::get('sessionKey');
		if(empty($key) || $key == 1){
			redirect('/signin');
			exit;
		}
		if(!empty(Session::get($key))){
			Session::destroy($key);
			Cookie::destroy('sessionKey');
			redirect('/signin');
			exit;
		}
	}

}