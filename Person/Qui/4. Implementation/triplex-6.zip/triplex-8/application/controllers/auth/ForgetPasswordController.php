<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/5/2017
 * Time: 8:54 PM
 */

class ForgetPasswordController extends MY_Controller  {

	/**
	 * LoginController constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 *
	 */
	public function index(){
		if($this->input->post()){
			$data = $this->input->post(array('email'));
			$email = $data['email'];
			$user = $this->Users_model->get_user_by_email($email);
			if(!empty($user)){
				$new_pass =  md5(microtime().rand());
				$this->Users_model->update_token_reset_password($user->id, $new_pass);
				// send mail
				$mailer = new Mail();
				$send_by = 'triplexcapstone@gmail.com';
				$recipient = $email;
				$subject = 'Reset password';
				$link = base_url().'forget?token='.$new_pass;
				$body = 'Click to here to reset your password: '.$link;
				$mailer->send_mail($subject, $body, $send_by, $recipient);
				redirect('/signin');
				exit;
			}else{
				$this->load->view('auth/forget');
			}
		}else{
			if(!empty($this->input->get('token'))){
				$token = $this->input->get('token');
				$user = $this->Users_model->get_by_password_restore($token);
				if(!empty($user)){
					$this->load->view('auth/reset');
				}else{
					$this->load->view('auth/forget');
				}
			}else{
				$this->load->view('auth/forget');
			}

		}
	 }

	/**
	 *
	 */
	public function reset_password(){
		 if($this->input->post()){
			 $data = $this->input->post(array('password', 'confirm_password'));
			 $password = $data['password'];
			 $confirm_password = $data['confirm_password'];
			 if($password  == $confirm_password){
				 $token = $this->input->post('token');
				 $user = $this->Users_model->get_by_password_restore($token);
				 $this->Users_model->update_password($user->id,  $this->encryption->encrypt($password));
				 redirect('/signin');
				 exit;
			 }else{
				 $this->load->view('auth/forget');
			 }
		 }else{
			 $this->load->view('auth/forget');
		 }
	 }
}