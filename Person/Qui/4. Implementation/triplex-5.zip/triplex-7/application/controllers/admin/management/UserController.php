<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/6/2017
 * Time: 8:56 PM
 */

class UserController extends Admin_Controller {

	protected $view_admin_student = 'admin/student/student';

	/**
	 * users constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	public function index(){
		$users = $this->Users_model->get_all();
		$data = [];
		$data['users'] = $users;
		$this->load_view($this->view_admin_student, $data);
	}

	public function create(){

	}

	public function import(){
		$config['upload_path']          = PRODIR.'/storage/resources/';
		$config['allowed_types']        = 'xlsx|csv';
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		if ($this->upload->do_upload('file')) {
			$upload_data = $this->upload->data();
			$file_name = $upload_data['file_name'];

			$this->import_file($config['upload_path'].$file_name);

		}

		redirect(base_url().'admin/users');
	}

	/**
	 * @param $Path
	 */
	private function import_file($Path){
//		$phpExcel = new PHPExcel();
		$objReader = PHPExcel_IOFactory::createReader('Excel2007');
		$objPHPExcel = $objReader->load($Path);
		$students = [];
		foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {
			foreach ($worksheet->getRowIterator() as $row) {
				if((int)$row->getRowIndex() > 1){
					$cellIterator = $row->getCellIterator();
					$cellIterator->setIterateOnlyExistingCells(false); // Loop all cells, even if it is not set
					$student = [];
					$mssv = 'B'.$row->getRowIndex();
					$first_name = 'C'.$row->getRowIndex();
					$last_name = 'D'.$row->getRowIndex();
					$birth_date = 'E'.$row->getRowIndex();
					$hasAddData = false;
					foreach ($cellIterator as $cell) {
						if (!is_null($cell)) {
							if($mssv == $cell->getCoordinate()){
								$student['mssv'] = $cell->getCalculatedValue();
								$student['account'] = $cell->getCalculatedValue();
								$student['password'] = $this->encryption->encrypt($cell->getCalculatedValue());
								$hasAddData = true;
							}

							if($first_name == $cell->getCoordinate()){
								$student['first_name'] = $cell->getCalculatedValue();
								$hasAddData = true;
							}

							if($last_name == $cell->getCoordinate()){
								$student['surname'] = $cell->getCalculatedValue();
								$hasAddData = true;
							}

							if($birth_date == $cell->getCoordinate()){
								$student['birth_date'] = $cell->getCalculatedValue();
								$hasAddData = true;
							}
						}
					}
					if($hasAddData){
						array_push($students, $student);
					}
				}
			}
		}
		$this->Users_model->insert_multi($students);
	}
}