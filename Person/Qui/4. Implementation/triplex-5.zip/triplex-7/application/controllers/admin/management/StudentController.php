<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/6/2017
 * Time: 8:56 PM
 */

class StudentController extends Admin_Controller {
	protected $view_admin_student = 'admin/student/student';

	/**
	 * users constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	public function index(){
		$this->load_view($this->view_admin_student);
	}

	public function create(){

	}

	private function get_student_ids(){

	}
}