<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/6/2017
 * Time: 8:24 PM
 */

class Cookie {

	public function __construct() {
	}

	public static function set($cookie_name, $cookie_value){
		setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day;
	}

	public static function get($cookie_name){
		if(isset($_COOKIE[$cookie_name])){
			return $_COOKIE[$cookie_name];
		}
		return null;

	}

	public static function update($cookie_name, $cookie_value){
		setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day;
	}

	public static function destroy($cookie_name){
		if (isset($_COOKIE[$cookie_name])) {
			setcookie($cookie_name, 1, time() + (86400 * 30), "/"); // 86400 = 1 day;
			unset($_COOKIE[$cookie_name]);
			return true;
		} else {
			return false;
		}
	}

}