<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body class="">
    <div id="header"><?= $header ?></div>
    <div id="contents"><?= $contents ?></div>
    <div id="footer"><?= $footer ?></div>
</body>
</html>