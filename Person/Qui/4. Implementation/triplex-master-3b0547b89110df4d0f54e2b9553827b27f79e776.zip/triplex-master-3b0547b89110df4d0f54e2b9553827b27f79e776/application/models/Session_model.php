<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/6/2017
 * Time: 9:52 PM
 */

class Session_model extends CI_Model {

	public $table_name = 'sessions';

	public function __construct() {
		parent::__construct();
	}

	public function insert_entry( $session = null ) {
		if ( empty( $session ) ) {
			return false;
		}
		$data              = [];
		$data['session'] = $session['session'];
		$data['key']  = $session['key'];
		$data['user_id']     = $session['user_id'];
		$data['env']     = 'web';
		$data['ip_remote']     = $session['ip_remote'];
		$my_date_time = date("Y-m-d H:i:s", strtotime("+5 hours"));
		$data['expire']     = strtotime($my_date_time);
		$this->db->insert( $this->table_name, $data );
		$insert_id = $this->db->insert_id();
		return $insert_id;
	}

	public function get_by_key($key){
		$sql   = "SELECT * FROM `sessions` WHERE `key` LIKE ?;" ;
		$query = $this->db->query( $sql, array($key) );
		if(!empty($query->result())){
			return $query->result()[0];
		}else{
			return null;
		}
	}

}