<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/9/2017
 * Time: 10:50 PM
 */

class Courses_model extends CI_Model {

	public $table_name = 'courses';

	public function __construct() {
		parent::__construct();
	}

	public function get_all(){
		$sql   = "SELECT c.`id`, c.`name`, c.`code`, ay.`name` as acadamic_year_name FROM `courses` as c, `academic_years` as ay WHERE c.`academic_years_id` = ay.`id` AND c.`deleted_date` IS NULL OR c.`deleted_date` = ''";
		$query = $this->db->query( $sql );
		return $query->result();
	}


	public function get_by_code($code){
		$sql   = "SELECT c.`id`, c.`name`, c.`code` FROM `courses` as c WHERE c.`code` = ?;" ;
		$query = $this->db->query( $sql, array($code) );
		if(!empty($query->result())){
			return $query->result()[0];
		}else{
			return null;
		}
	}

	public function insert($data){
		$this->db->insert( $this->table_name, $data );
		$insert_id = $this->db->insert_id();
		return $insert_id;
	}

}