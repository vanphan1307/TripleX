<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Title of the document</title>
</head>

<body>
Content of the document......
</body>

</html>