<!-- User info -->
<div class="login-info">
				<span> <!-- User image size is adjusted inside CSS, it should stay as it -->

					<a href="javascript:void(0);" id="show-shortcut" data-action="toggleShortcut">
						<img src="<?= base_url();?>assets/smartadmin/img/avatars/if_user-01_186382.png" alt="me" class="online" />
						<span>
							john.doe
						</span>
					</a>

				</span>
</div>
<!-- end user info -->

<nav>
    <ul>
        <li class="active">
            <a href="<?= base_url();?>admin" title="Dashboard"><i class="fa fa-lg fa-fw fa-home"></i> <span class="menu-item-parent">Home</span></a>
        </li>
        <li>
            <a href="<?= base_url();?>admin/users" title="Dashboard"><i class="fa fa-address-book-o" aria-hidden="true"></i> <span class="menu-item-parent">Quẩn lý tài khoản</span></a>
        </li>
        <li>
            <a href="<?= base_url();?>admin/acadamicyears" title="Dashboard"><i class="fa fa-address-book-o" aria-hidden="true"></i> <span class="menu-item-parent">Quẩn lý năm học</span></a>
        </li>
        <li>
            <a href="<?= base_url();?>admin/score/test" title="Dashboard"><i class="fa fa-building-o" aria-hidden="true"></i> <span class="menu-item-parent">Quản lý điểm thi</span></a>
        </li>
        <li>
            <a href="<?= base_url();?>admin/score/semester" title="Dashboard"><i class="fa fa-braille" aria-hidden="true"></i> <span class="menu-item-parent">Quản lý điểm học kỳ</span></a>
        </li>
        <li>
            <a href="<?= base_url();?>admin/courses" title="Dashboard"><i class="fa fa-tags" aria-hidden="true"></i> <span class="menu-item-parent">Quản lý môn học</span></a>
        </li>
        <li>
            <a href="<?= base_url();?>admin/classes" title="Dashboard"><i class="fa fa-th-list" aria-hidden="true"></i> <span class="menu-item-parent">Quản lý lớp học</span></a>
        </li>
        <li>
            <a href="<?= base_url();?>admin/timetable" title="Dashboard"><i class="fa fa-calendar" aria-hidden="true"></i> <span class="menu-item-parent">Quản lý thời khóa biểu</span></a>
        </li>
        <li>
            <a href="<?= base_url();?>admin/test/schedule" title="Dashboard"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span class="menu-item-parent">Quản lý lịch thi</span></a>
        </li>
    </ul>
</nav>

<span class="minifyme" data-action="minifyMenu">
    <i class="fa fa-arrow-circle-left hit"></i>
</span>