<div class="rows">
    <!-- widget grid -->
    <section id="widget-grid" class="">
        <!-- START ROW -->
        <div class="row">
            <!-- NEW COL START -->
            <article class="col-sm-12 col-md-12 col-lg-3">

                <!-- Widget ID (each widget will need unique ID)-->
                <div class="jarviswidget" id="wid-id-1" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-custombutton="false">
                    <!-- widget options:
					usage: <div class="jarviswidget" id="wid-id-0" data-widget-editbutton="false">

					data-widget-colorbutton="false"
					data-widget-editbutton="false"
					data-widget-togglebutton="false"
					data-widget-deletebutton="false"
					data-widget-fullscreenbutton="false"
					data-widget-custombutton="false"
					data-widget-collapsed="true"
					data-widget-sortable="false"

					-->
                    <header>
                        <span class="widget-icon"> <i class="fa fa-edit"></i> </span>
                        <h2>Import Điểm thi </h2>

                    </header>

                    <!-- widget div-->
                    <div>

                        <!-- widget edit box -->
                        <div class="jarviswidget-editbox">
                            <!-- This area used as dropdown edit box -->

                        </div>
                        <!-- end widget edit box -->

                        <!-- widget content -->
                        <div class="widget-body no-padding">

                            <form class="smart-form" action="<?= base_url() ?>admin/score/test/import" method="post" enctype="multipart/form-data">
                                <fieldset>
                                    <section>
                                        <label class="label">File import</label>
                                        <div class="input input-file">
                                            <span class="button"><input type="file" id="file" name="file" onchange="this.parentNode.nextSibling.value = this.value">Browse</span><input type="text" placeholder="Include some files" readonly="">
                                        </div>
                                    </section>
                                </fieldset>

                                <footer>
                                    <button type="submit" class="btn btn-primary">
                                        Submit
                                    </button>
                                </footer>
                            </form>

                        </div>
                        <!-- end widget content -->

                    </div>
                    <!-- end widget div -->

                </div>
                <!-- end widget -->

            </article>
            <!-- END COL -->

            <!-- NEW COL START -->
            <article class="col-sm-12 col-md-12 col-lg-9">

                <!-- Widget ID (each widget will need unique ID)-->
                <div class="jarviswidget" id="wid-id-1" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-custombutton="false">
                    <!-- widget options:
					usage: <div class="jarviswidget" id="wid-id-0" data-widget-editbutton="false">

					data-widget-colorbutton="false"
					data-widget-editbutton="false"
					data-widget-togglebutton="false"
					data-widget-deletebutton="false"
					data-widget-fullscreenbutton="false"
					data-widget-custombutton="false"
					data-widget-collapsed="true"
					data-widget-sortable="false"

					-->
                    <header>
                        <span class="widget-icon"> <i class="fa fa-edit"></i> </span>
                        <h2>Điểm Thi </h2>

                    </header>

                    <!-- widget div-->
                    <div>

                        <!-- widget edit box -->
                        <div class="jarviswidget-editbox">
                            <!-- This area used as dropdown edit box -->

                        </div>
                        <!-- end widget edit box -->

                        <!-- widget content -->
                        <div class="widget-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th>MSSV</th>
                                        <th>Full name</th>
                                        <th>MÃ MH</th>
                                        <th>CHUYÊN CÂN</th>
                                        <th>GIỮA KỲ</th>
                                        <th>LAN 1</th>
                                        <th>LAN 2</th>
                                        <th>ĐTB</th>
                                        <th>% CHUYÊN CÂN</th>
                                        <th>% GIỮA KỲ</th>
                                        <th>% THI</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
									<?php
                                    foreach ($scores as $score){
                                        ?>
                                        <tr>
                                            <td><?= $score->mssv ?></td>
                                            <td><?= $score->first_name . ' ' . $score->surname ?></td>
                                            <td><?= $score->course_code ?></td>
                                            <td><?= $score->attendance ?></td>
                                            <td><?= $score->mid_term ?></td>
                                            <td><?= $score->first_time ?></td>
                                            <td><?= $score->second_time ?></td>
                                            <td><?= $score->DTB ?></td>
                                            <td><?= $score->percent_attendance ?></td>
                                            <td><?= $score->percent_mid_term ?></td>
                                            <td><?= $score->percent_last_test ?></td>
                                            <td>
                                                <a href="<?= base_url() ?>admin/score/test/delete?s=<?= $score->id ?>" class="btn btn-default btn-sm">Delete</a>
                                            </td>
                                        </tr>
                                    <?php
                                    }
									?>
                                    </tbody>
                                </table>
                                <div class="row">

                                </div>
                            </div>
                        </div>
                        <!-- end widget content -->

                    </div>
                    <!-- end widget div -->

                </div>
                <!-- end widget -->

            </article>
            <!-- END COL -->
        </div>
        <!-- END ROW -->
    </section>
    <!-- end widget grid -->
</div>
