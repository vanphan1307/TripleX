<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/8/2017
 * Time: 4:30 PM
 */

class TeacherController extends Admin_Controller {
	/**
	 * users constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	public function index(){

	}

	public function create(){

	}
}