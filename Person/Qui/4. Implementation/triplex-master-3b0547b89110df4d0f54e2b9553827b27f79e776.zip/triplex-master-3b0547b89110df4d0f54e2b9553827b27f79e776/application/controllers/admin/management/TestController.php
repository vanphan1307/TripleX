<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/16/2017
 * Time: 8:56 PM
 */

class TestController extends Admin_Controller {

	protected $view_admin_test = 'admin/test/test';

	/**
	 * TestController constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	public function index(){
		$schedules = $this->TestSchedule_model->fetch_all();
		$data = [];
		$data['schedules'] = $schedules;
		$this->load_view($this->view_admin_test, $data);
	}

	public function schedule(){
		if($this->input->post()){
			$config['upload_path']          = PRODIR.'/storage/schedules/';
			$config['allowed_types']        = 'gif|jpg|png';
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			if ($this->upload->do_upload('file')) {
				$upload_data = $this->upload->data();
				$file_name = $upload_data['file_name'];
				$schedule = [];
				$schedule['name'] = $this->input->post('name');
				$schedule['img'] = base_url().'storage/schedules/'.$file_name;
				$this->TestSchedule_model->insert_entry($schedule);
			}
		}
		redirect(base_url().'admin/test/schedule');
	}

	public function delete(){
		$id = (int)$this->input->get('s');
		$this->TestSchedule_model->delete($id);
		redirect(base_url().'admin/test/schedule');
	}
}