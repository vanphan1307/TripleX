<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/6/2017
 * Time: 8:56 PM
 */

class ScoreController extends Admin_Controller {

	protected $view_admin_score_test = 'admin/score/test/index';

	protected $view_admin_student_review = 'admin/score/test//review';

	/**
	 * users constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	public function index(){
		if($this->input->get('import')){
			$this->import_file_into_db($this->input->get('import'));
			redirect(base_url().'admin/score/test');
			exit;
		}
		$acadamic_years = $this->AcademicYears_model->get_all();
		$course = $this->Courses_model->get_all();
		$scores = $this->ScoreTest_model->get_all();
		$data = [];
		$data['acadamic_years'] = $acadamic_years;
		$data['courses'] = $course;
		$data['scores'] = $scores;
		$this->load_view($this->view_admin_score_test, $data);
	}

	public function import(){
		$config['upload_path']          = PRODIR.'/storage/resources/';
		$config['allowed_types']        = 'xlsx|csv';
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$students = [];
		if ($this->upload->do_upload('file')) {
			$upload_data = $this->upload->data();
			$file_name = $upload_data['file_name'];

			$students = $this->import_file($config['upload_path'].$file_name);

		}
		$data = [];
		$data['users'] = $students;
		$data['filePath'] = $config['upload_path'].$file_name;
		$this->load_view($this->view_admin_student_review, $data);
	}

	/**
	 * @param $Path
	 */
	private function import_file_into_db($Path){
		$objReader = PHPExcel_IOFactory::createReader('Excel2007');
		$objPHPExcel = $objReader->load($Path);
		foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {
			$sheetName = $worksheet->getTitle();
			if($sheetName == 'DIEM'){
				foreach ($worksheet->getRowIterator() as $row) {
					if((int)$row->getRowIndex() > 5){
						$cellIterator = $row->getCellIterator();
						$cellIterator->setIterateOnlyExistingCells(false); // Loop all cells, even if it is not set
						$student = [];
						$mssv = 'B'.$row->getRowIndex();
						$first_name = 'C'.$row->getRowIndex();
						$last_name = 'D'.$row->getRowIndex();
						$birth_date = 'E'.$row->getRowIndex();
						$class = 'F'.$row->getRowIndex();
						$courses_code = 'H'.$row->getRowIndex();
						$couses_name = 'I'.$row->getRowIndex();
						$j = 'J'.$row->getRowIndex();
						$k = 'K'.$row->getRowIndex();
						$l = 'L'.$row->getRowIndex();
						$m = 'M'.$row->getRowIndex();
						$n = 'N'.$row->getRowIndex();
						$o = 'M'.$row->getRowIndex();
						$p = 'P'.$row->getRowIndex();
						$q = 'Q'.$row->getRowIndex();
						foreach ($cellIterator as $cell) {
							if (!is_null($cell)) {
								if($mssv == $cell->getCoordinate()){
									$_mssv = $cell->getCalculatedValue();
									$user = $this->Users_model->get_user_by_mssv($_mssv);
									if(!empty($user)){
										$student['user_id'] = (int)$user->id;
									}else{
										$student['user_id'] = null;
									}
								}

								if($courses_code == $cell->getCoordinate()){
									$course_code= $cell->getCalculatedValue();
									$course = $this->Courses_model->get_by_code($course_code);
									if(!empty($course)){
										$student['courses_id'] = (int)$course->id;
									}else{
										$student['courses_id'] = null;
									}
								}

								if($j == $cell->getCoordinate()){
									$student['attendance'] = $cell->getCalculatedValue();
								}

								if($k == $cell->getCoordinate()){
									$student['mid_term'] = $cell->getCalculatedValue();
								}

								if($l == $cell->getCoordinate()){
									$student['first_time'] = $cell->getCalculatedValue();
								}

								if($m == $cell->getCoordinate()){
									$student['second_time'] = $cell->getCalculatedValue();
								}

								if($n == $cell->getCoordinate()){
									$student['DTB'] = $cell->getCalculatedValue();
								}

								if($o == $cell->getCoordinate()){
									$student['percent_attendance'] = $cell->getCalculatedValue();
								}

								if($p == $cell->getCoordinate()){
									$student['percent_mid_term'] = $cell->getCalculatedValue();
								}

								if($q == $cell->getCoordinate()){
									$student['percent_last_test'] = $cell->getCalculatedValue();
								}
							}
						}
						if(empty($student['courses_id'])){
							continue;
						}
						if(empty($student['user_id'])){
							continue;
						}
						$score = $this->ScoreTest_model->get_by_course_id_and_user_id($student['courses_id'], $student['user_id']);
						if(empty($score)){
							$this->ScoreTest_model->insert($student);
						}else{

						}
					}
				}
			}

		}
	}



	/**
	 * @param $Path
	 * @return array[] students
	 */
	private function import_file($Path){
		$objReader = PHPExcel_IOFactory::createReader('Excel2007');
		$objPHPExcel = $objReader->load($Path);
		$students = [];
		foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {
			$sheetName = $worksheet->getTitle();
			if($sheetName == 'DIEM'){
				foreach ($worksheet->getRowIterator() as $row) {
					if((int)$row->getRowIndex() > 5){
						$cellIterator = $row->getCellIterator();
						$cellIterator->setIterateOnlyExistingCells(false); // Loop all cells, even if it is not set
						$student = [];
						$mssv = 'B'.$row->getRowIndex();
						$first_name = 'C'.$row->getRowIndex();
						$last_name = 'D'.$row->getRowIndex();
						$birth_date = 'E'.$row->getRowIndex();
						$class = 'F'.$row->getRowIndex();
						$courses_code = 'H'.$row->getRowIndex();
						$couses_name = 'I'.$row->getRowIndex();
						$j = 'J'.$row->getRowIndex();
						$k = 'K'.$row->getRowIndex();
						$l = 'L'.$row->getRowIndex();
						$m = 'M'.$row->getRowIndex();
						$n = 'N'.$row->getRowIndex();
						$o = 'M'.$row->getRowIndex();
						$p = 'P'.$row->getRowIndex();
						$q = 'Q'.$row->getRowIndex();
						$hasAddData = false;
						foreach ($cellIterator as $cell) {
							if (!is_null($cell)) {
								if($mssv == $cell->getCoordinate()){
									$student['mssv'] = $cell->getCalculatedValue();
									$student['account'] = $cell->getCalculatedValue();
									$student['password'] = $this->encryption->encrypt($cell->getCalculatedValue());
									$hasAddData = true;
								}

								if($first_name == $cell->getCoordinate()){
									$student['first_name'] = $cell->getCalculatedValue();
									$hasAddData = true;
								}

								if($last_name == $cell->getCoordinate()){
									$student['surname'] = $cell->getCalculatedValue();
									$hasAddData = true;
								}

								if($birth_date == $cell->getCoordinate()){
									$student['birth_date'] = $cell->getCalculatedValue();
									$hasAddData = true;
								}

								if($class == $cell->getCoordinate()){
									$student['class'] = $cell->getCalculatedValue();
									$hasAddData = true;
								}


								if($courses_code == $cell->getCoordinate()){
									$student['course_code'] = $cell->getCalculatedValue();
									$hasAddData = true;
								}

								if($couses_name == $cell->getCoordinate()){
									$student['course_name'] = $cell->getCalculatedValue();
									$hasAddData = true;
								}

								if($j == $cell->getCoordinate()){
									$student['j'] = $cell->getCalculatedValue();
									$hasAddData = true;
								}

								if($k == $cell->getCoordinate()){
									$student['k'] = $cell->getCalculatedValue();
									$hasAddData = true;
								}

								if($l == $cell->getCoordinate()){
									$student['l'] = $cell->getCalculatedValue();
									$hasAddData = true;
								}

								if($m == $cell->getCoordinate()){
									$student['m'] = $cell->getCalculatedValue();
									$hasAddData = true;
								}

								if($n == $cell->getCoordinate()){
									$student['n'] = $cell->getCalculatedValue();
									$hasAddData = true;
								}

								if($o == $cell->getCoordinate()){
									$student['o'] = $cell->getCalculatedValue();
									$hasAddData = true;
								}

								if($p == $cell->getCoordinate()){
									$student['p'] = $cell->getCalculatedValue();
									$hasAddData = true;
								}

								if($q == $cell->getCoordinate()){
									$student['q'] = $cell->getCalculatedValue();
									$hasAddData = true;
								}
							}
						}
						if(empty($student['mssv']) || trim($student['mssv']) == ''){
							continue;
						}
						if($hasAddData){
							array_push($students, $student);
						}
					}
				}
			}
		}
		return $students;
	}

}