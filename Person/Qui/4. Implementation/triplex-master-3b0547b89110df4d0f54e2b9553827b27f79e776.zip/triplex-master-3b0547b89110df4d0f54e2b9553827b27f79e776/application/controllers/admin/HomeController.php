<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/6/2017
 * Time: 10:04 PM
 */

class HomeController extends Admin_Controller {

	protected $view_admin = 'admin/home';
	/**
	 * homeController constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	public function index(){
		$this->load_view($this->view_admin);
	}

}