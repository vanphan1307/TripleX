<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/6/2017
 * Time: 8:56 PM
 */

class CourseController extends Admin_Controller {

	protected $view_admin_academic_year = 'admin/courses/index';

	/**
	 * users constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	public function index(){
		$acadamic_years = $this->AcademicYears_model->get_all();
		$course = $this->Courses_model->get_all();
		$data = [];
		$data['acadamic_years'] = $acadamic_years;
		$data['courses'] = $course;
		$this->load_view($this->view_admin_academic_year, $data);
	}

	public function create(){
		if($this->input->post()){
			$name = $this->input->post('name');
			$code = $this->input->post('code');
			$academicyear = $this->input->post('academicyear');
			$data = [];
			$data['name'] = $name;
			$data['academic_years_id'] = (int)$academicyear;
			$data['code'] = $code;
			$this->Courses_model->insert($data);
			redirect(base_url().'admin/courses');
		}else{
			redirect(base_url().'admin/courses');
		}
	}

}