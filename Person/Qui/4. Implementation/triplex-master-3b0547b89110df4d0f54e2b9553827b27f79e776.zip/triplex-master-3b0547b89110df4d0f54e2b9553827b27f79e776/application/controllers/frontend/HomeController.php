<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/6/2017
 * Time: 10:04 PM
 */

class HomeController extends Frontend_Controller {

	/**
	 * homeController constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	public function index(){
		$this->load->view('frontend/home');
	}

}