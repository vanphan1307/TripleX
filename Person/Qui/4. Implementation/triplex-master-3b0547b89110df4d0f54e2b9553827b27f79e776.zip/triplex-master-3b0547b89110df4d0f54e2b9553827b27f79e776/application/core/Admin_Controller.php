<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/5/2017
 * Time: 10:41 PM
 */

class Admin_Controller extends MY_Controller {
	/**
	 * Obj user
	 * */
	public $user = null;

	/**
	 * String constant master admin page path
	 * */
	private $master_page_path = 'admin/layouts/masterpage';

	/**
	 * String constant master admin header page path
	 * */
	private $master_page_header_path = 'admin/layouts/header';

	/**
	 * String constant master admin navigation page path
	 * */
	private $master_page_navigation_path = 'admin/layouts/navigation';

	/**
	 * String constant master admin footer page path
	 * */
	private $master_page_footer_path = 'admin/layouts/footer';

	/**
	 * list permission of the module
	**/
	public $permission = array();


	/**
	 * Main_Controller constructor.
	 */
	public function __construct() {
		parent::__construct();
		//check user login
		$this->isLogon();
		// load permission
		$this->load_permission();
	}

	/**
	 * The first time login into the system, we will check by session key
	 * return sign in view if the session expired
	 */
	public function isLogon(){
		$key = Cookie::get('sessionKey');
		if(empty($key) || $key == 1){
			redirect('/signin');
			exit;
		}
		if(empty(Session::get($key))){
			Cookie::destroy('sessionKey');
			redirect('/signin');
			exit;
		}
		$this->user = Session::get_current_user();
		$userId = $this->user->id;
		$user_group = $this->UserGroups_model->get_by_user_id($userId);
		if(!in_array($user_group->group_id, [2, 4, 5])){
			redirect('/');
		}
	}

	/**
	 * @param $view_name
	 * @param array $view_data
	 */
	public function load_view($view_name, $view_data = array()){
		$views = [];
		$views['page'] = $view_name;
		$views['header'] = $this->master_page_header_path;
		$views['nav'] = $this->master_page_navigation_path;
		$views['footer'] = $this->master_page_footer_path;
		$this->template->load($this->master_page_path, $views, $view_data);
	}

	private function get_active_module(){
		
	}

	private function load_permission(){

	}
}