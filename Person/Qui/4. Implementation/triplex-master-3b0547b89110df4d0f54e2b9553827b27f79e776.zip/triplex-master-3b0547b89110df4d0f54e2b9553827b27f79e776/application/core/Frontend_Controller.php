<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/5/2017
 * Time: 10:41 PM
 */

class Frontend_Controller extends MY_Controller {
	public $user = null;

	public $template = null;

	private $master_page_path = 'frontend/layouts/masterpage';

	private $master_page_header_path = 'frontend/layouts/header';

	private $master_page_footer_path = 'frontend/layouts/footer';


	/**
	 * Main_Controller constructor.
	 */
	public function __construct() {
		parent::__construct();
		$this->isLogon();
	}

	/**
	 *
	 */
	public function isLogon(){
		$key = Cookie::get('sessionKey');
		if(empty($key) || $key == 1){
			redirect('/signin');
			exit;
		}
		if(empty(Session::get($key))){
			Cookie::destroy('sessionKey');
			redirect('/signin');
			exit;
		}
		$this->user = Session::get($key);
		$userId = $this->user->id;
		$user_group = $this->UserGroups_model->get_by_user_id($userId);
		if(in_array($user_group->group_id, [2, 4, 5])){
			redirect('/admin');
		}
	}

	/**
	 * @param $view_name
	 * @param array $view_data
	 */
	public function load_view($view_name, $view_data = array()){
		$views = [];
		$views['page'] = $view_name;
		$views['header'] = $this->master_page_header_path;
		$views['footer'] = $this->master_page_footer_path;
		$this->template->load($this->master_page_path, $views, $view_data);
	}
}