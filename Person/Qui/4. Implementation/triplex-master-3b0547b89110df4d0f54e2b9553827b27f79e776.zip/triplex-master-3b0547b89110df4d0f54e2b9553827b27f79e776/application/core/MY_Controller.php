<?php
/**
 * Created by PhpStorm.
 * User: Vu
 * Date: 10/5/2017
 * Time: 10:41 PM
 */

class MY_Controller extends CI_Controller {
	/**
	 * MY_Controller constructor.
	 */
	public function __construct() {
		parent::__construct();
	}
}